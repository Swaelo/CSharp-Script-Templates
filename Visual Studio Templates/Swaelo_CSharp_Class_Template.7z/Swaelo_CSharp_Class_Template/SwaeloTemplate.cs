﻿// ================================================================================================================================
// File:        $safeitemname$.cs
// Description: 
// Author:	    Harley Laurie https://www.github.com/Swaelo/
// ================================================================================================================================

using System;
using System.Collections.Generic;

namespace $rootnamespace$
{
    public class $safeitemname$
    {
        
    }
}